import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, ILike, LessThan } from 'typeorm';
import { MuseumEntity } from './museum.entity';
import { MuseumQueryDto } from './museum-query.dto';

@Injectable()
export class MuseumService {
  constructor(
    @InjectRepository(MuseumEntity)
    private readonly museumRepository: Repository<MuseumEntity>,
  ) {}

  async findAll(query: MuseumQueryDto) {
    const page = query.page ?? 1;
    const limit = query.limit ?? 10;
    const skip = (page - 1) * limit;

    const where: any = {};

    if (query.city) {
      where.city = ILike(`%${query.city}%`);
    }

    if (query.name) {
      where.name = ILike(`%${query.name}%`);
    }

    if (query.foundedBefore) {
      where.foundedBefore = LessThan(query.foundedBefore);
    }

    const [data, total] = await this.museumRepository.findAndCount({
      where,
      skip,
      take: limit,
    });

    return {
      data,
      meta: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      },
    };
  }
}